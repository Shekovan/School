from flask import Flask, render_template, request
from funciones import carga_csv, peliculas_mas_recientes
from funciones import crea_diccionario_peliculas
from funciones import crea_diccionario_genero
from funciones import crea_diccionario_anio
from funciones import crea_diccionario_letras
import os

archivo_cartelera = 'cartelera_2024.csv'
app = Flask(__name__)
cartelera = carga_csv(archivo_cartelera)
diccionario_peliculas = crea_diccionario_peliculas(cartelera)
diccionario_generos = crea_diccionario_genero(cartelera)
diccionario_anios = crea_diccionario_anio(cartelera)
diccionario_letras = crea_diccionario_letras(cartelera)


@app.route("/")
def index():
    global cartelera
    lista_peliculas = peliculas_mas_recientes(cartelera)
    return render_template("index.html", lista=lista_peliculas)


@app.route("/genero")
def generos():
    return render_template("generos.html", dicc_generos=diccionario_generos)


@app.route("/genero/<id>")
def generosconid(id: str):
    if id.upper() in diccionario_generos:
        diccionario_generosNuevo = {id.upper(): diccionario_generos[id.upper()]}
        return render_template("generos.html", dicc_generos=diccionario_generosNuevo)
    else:
        return render_template("no_existe.html")


@app.route("/anios")
def anio():
    return render_template("anio.html", dicc_anios=diccionario_anios)


@app.route("/anios/<id>")
def anioconid(id: str):
    if id in diccionario_anios:
        diccionario_aniosNuevo = {id: diccionario_anios[id]}
        return render_template("anio.html", dicc_anios=diccionario_aniosNuevo)
    else:
        return render_template("no_existe.html")


@app.route("/alfabetico")
def alfabetico():
    return render_template("alfabetico.html", diccionario_letras=diccionario_letras)


@app.route("/alfa/<id>")
def alfabeticoconid(id: str):
    if id in diccionario_letras:
        diccionario_letrasNuevo = {id: diccionario_letras[id]}
        return render_template("alfabetico.html", diccionario_letras=diccionario_letrasNuevo)
    else:
        return render_template("no_existe.html")


@app.route("/pelicula/<id>")
def pelicula(id: str):
    if id in diccionario_peliculas:
        pelicula = diccionario_peliculas[id]
        print(f"movie={pelicula['titulo']}")
        return render_template("movie.html", movie=pelicula)
    else:
        return render_template("no_existe.html")


@app.errorhandler(404)
def page_not_found(error):
    return render_template("no_existe.html"), 404


if __name__ == "__main__":
    app.run(debug=True)
